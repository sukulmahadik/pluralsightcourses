All examples in the course demos use Jupyter Notebook.

The suggested set-up is to download and install Anaconda Python distribution: https://www.anaconda.com/download/. Installing Anaconda will also install the Jupyter Notebook executable.

I strongly suggest to add the Anaconda to the system path when asked at the end of the installation.

For the smoothest experience, unpack the materials, then navigate in terminal (Powershell in case of Windows) to the folder with unpacked files, and run 'jupyter notebook .' from there.

Demos were prepared using Python 3.6.4 and Pandas 0.23.
