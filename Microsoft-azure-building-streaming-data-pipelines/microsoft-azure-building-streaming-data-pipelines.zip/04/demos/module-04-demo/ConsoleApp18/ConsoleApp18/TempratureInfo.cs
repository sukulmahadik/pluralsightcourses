﻿using System;

namespace ConsoleApp18
{
    public class TempratureInfo
    {
        public Guid Id { get; set; }

        public double TempratureCelcius { get; set; }

        public string SensorId { get; set; }

        public DateTime EventTime { get; set; }
    }
}