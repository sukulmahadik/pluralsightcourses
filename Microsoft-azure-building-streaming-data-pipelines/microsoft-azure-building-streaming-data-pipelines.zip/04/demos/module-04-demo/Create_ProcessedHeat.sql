
CREATE TABLE [dbo].[ProcessedHeat](
	[Temp] [int] NOT NULL,
	[SensorId] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO


