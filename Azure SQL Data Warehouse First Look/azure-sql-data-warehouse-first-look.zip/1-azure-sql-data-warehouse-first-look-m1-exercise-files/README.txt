Demo #1: Follow the instructions on file: CreateYourDWThroughThePortal.txt
Demo #2: Azure Powershell can be found here: https://azure.microsoft.com/en-us/documentation/articles/powershell-install-configure/
Once installation is complete, follow the demo and use script file NewDW.ps1 as a guide.