select sum(UnitsBalance) FullBalance from prod.FactProductInventory;
GO 10000