USE [HappyScoopers_DW]
GO

SELECT * FROM [int].[Lineage]
ORDER BY StartLoad DESC