The dumps provided in this folder are for demo purposes only. They are not and should not be used for any purpose other than testing importing relational data for this course.

For a full dump of StackOverflow please check https://archive.org/details/stackexchange